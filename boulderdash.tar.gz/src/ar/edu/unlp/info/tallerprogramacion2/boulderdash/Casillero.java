package ar.edu.unlp.info.tallerprogramacion2.boulderdash;

public class Casillero {
	private Personaje personaje;
	

	public Personaje getPersonaje() {
		return personaje;
	}

	public void setPersonaje(Personaje personaje) {
		this.personaje = personaje;
	}
	

}
