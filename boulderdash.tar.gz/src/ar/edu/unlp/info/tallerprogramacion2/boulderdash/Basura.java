/**
 * 
 */
package ar.edu.unlp.info.tallerprogramacion2.boulderdash;

/**
 * @author mario
 *
 */
public class Basura extends Personaje {

	public Basura(Posicion posicion) {
		super(posicion);
		// TODO Auto-generated constructor stub
	}
	
}
