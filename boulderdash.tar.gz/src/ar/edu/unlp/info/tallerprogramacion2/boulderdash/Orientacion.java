/**
 * 
 */
package ar.edu.unlp.info.tallerprogramacion2.boulderdash;

/**
 * @author mario
 *
 */
public enum Orientacion {
	ARRIBA		,
	ABAJO		,
	IZQUIERDA	,
	DERECHA
}
