/**
 * 
 */
package ar.edu.unlp.info.tallerprogramacion2.boulderdash;

/**
 * @author mario
 *
 */
public class TestBoulderDash {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Juego juego = Juego.getInstance();
		int nivel = 1;
		int turno = 1;

		Rockford rockford = Rockford.getInstance();
		
		juego.cargarNievel(nivel);
		
		System.out.println();
		System.out.println();
		System.out.println("--------------------------------------");
		System.out.println("Simulacion del nivel 1");
		System.out.println();
		System.out.println();
		
		
		while (!(juego.getNivel().isFin()) && (turno < 35)) {
			
			System.out.println("Turno " + turno);
			simularTurnoRockford(nivel, turno, rockford);
			juego.ejecutarTurno();
			turno++;
		}
		
		System.out.println();
		System.out.println();
		System.out.println("--------------------------------------");
		System.out.println("Simulacion del nivel 2");
		
		nivel = 2;
		juego.cargarNievel(nivel);
		turno = 1;
		juego.getNivel().setFin(false);
		
		while (!(juego.getNivel().isFin()) && (turno < 25)) {
			System.out.println("Turno " + turno);
			simularTurnoRockford(nivel, turno, rockford);
			juego.ejecutarTurno();
			turno++;
		}
	}
	
	public static void simularTurnoRockford(int nivel, int turno, Rockford rockford) {
	
		if (nivel == 1) {
			switch (turno) {
			case 1:
				rockford.mover(Orientacion.ABAJO);
				break;
			case 2:
				rockford.mover(Orientacion.DERECHA);			
				break;
			case 3:
				rockford.mover(Orientacion.DERECHA);			
				break;
			case 4:
				rockford.mover(Orientacion.DERECHA);
				break;
			case 5:
				rockford.mover(Orientacion.DERECHA);
				break;
			case 6:
				rockford.mover(Orientacion.DERECHA);
				break;
			case 7:
				rockford.mover(Orientacion.DERECHA);
				break;
			case 8:
				rockford.mover(Orientacion.DERECHA);
				break;
			case 9:
				rockford.mover(Orientacion.ARRIBA);
				break;
			case 10:
				rockford.mover(Orientacion.ARRIBA);
				break;
			case 11:
				rockford.mover(Orientacion.DERECHA);
				break;
			case 12:
				rockford.mover(Orientacion.ABAJO);
				break;
			case 13:
				rockford.mover(Orientacion.ABAJO);
				break;
			case 14:
				rockford.mover(Orientacion.DERECHA);
				break;
			case 15:
				rockford.mover(Orientacion.DERECHA);
				break;
			case 16:
				rockford.mover(Orientacion.DERECHA);
				break;
			case 17:
				rockford.mover(Orientacion.DERECHA);
				break;
			case 18:
				rockford.mover(Orientacion.DERECHA);
				break;
			case 19:
				rockford.mover(Orientacion.DERECHA);
				break;
			case 20:
				rockford.mover(Orientacion.DERECHA);
				break;
			case 21:
				rockford.mover(Orientacion.DERECHA);
				break;
			case 22:
				rockford.mover(Orientacion.ABAJO);
				break;
			case 23:
				rockford.mover(Orientacion.ABAJO);
				break;
			case 24:
				rockford.mover(Orientacion.DERECHA);
				break;
			case 25:
				rockford.mover(Orientacion.DERECHA);
				break;
			case 26:
				rockford.mover(Orientacion.DERECHA);
				break;
			case 27:
				rockford.mover(Orientacion.DERECHA);
				break;
			case 28:
				rockford.mover(Orientacion.DERECHA);
				break;
			}
			
			if (nivel == 2) {

				switch (turno) {
				case 1:
					rockford.mover(Orientacion.DERECHA);
					break;
				case 2:
					rockford.mover(Orientacion.ARRIBA);			
					break;
				case 3:
					rockford.mover(Orientacion.ARRIBA);			
					break;
				case 4:
					rockford.mover(Orientacion.ARRIBA);
					break;
				case 5:
					rockford.mover(Orientacion.IZQUIERDA);
					break;
				case 6:
					rockford.mover(Orientacion.IZQUIERDA);
					break;
				case 7:
					rockford.mover(Orientacion.IZQUIERDA);
					break;
				case 8:
					rockford.mover(Orientacion.IZQUIERDA);
					break;
				case 9:
					rockford.mover(Orientacion.IZQUIERDA);
					break;
				case 10:
					rockford.mover(Orientacion.IZQUIERDA);
					break;
				case 11:
					rockford.mover(Orientacion.IZQUIERDA);
					break;
				case 12:
					rockford.mover(Orientacion.IZQUIERDA);
					break;
				case 13:
					rockford.mover(Orientacion.IZQUIERDA);
					break;
				case 14:
					rockford.mover(Orientacion.IZQUIERDA);
					break;
				case 15:
					rockford.mover(Orientacion.IZQUIERDA);
					break;
				case 16:
					rockford.mover(Orientacion.IZQUIERDA);
					break;
				case 17:
					rockford.mover(Orientacion.IZQUIERDA);
					break;
				case 18:
					rockford.mover(Orientacion.IZQUIERDA);
					break;
				case 19:
					rockford.mover(Orientacion.ARRIBA);
					break;
				}
				
			}
		}
	
	}
}

