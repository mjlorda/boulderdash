package ar.edu.unlp.info.tallerprogramacion2.boulderdash;

public class EspacioVacio extends Personaje{
	public EspacioVacio(Posicion posicion) {
		super(posicion);
	}
	
}
