package ar.edu.unlp.info.tallerprogramacion2.boulderdash;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import mapa.BDLevelReader;

public class Juego {
	
	public final int FILAS = 22;
	public final int COLUMNAS = 40;

	private static Juego juego;
	private Nivel nivel;
	private BDLevelReader levelReader;
	private boolean rockforSeMurio;
	private Casillero[][] tablero;
	
	/** Lista de niveles disponibles */
	private List<Nivel> niveles;
	
	/**
	 * Lista de personajes animados, la cual es recorrida en cada turno para que cada personaje
	 * realice las acciones que le corresponden
	 */
	private List<PersonajeAnimado> listaAnimados;
	/**
	 * Lista donde se cargan los personajes que se van eliminando durante un turno, que seran removidos 
	 * de la listaAnimados al finalizar el turno.
	 */
	private List<PersonajeAnimado> listaAnimadosEliminados;
	
	private List<PersonajeAnimado> listaAnimadosAgregados;

	private Juego() {
		this.tablero = new Casillero[FILAS][COLUMNAS];
		this.listaAnimados = new LinkedList<PersonajeAnimado>();
		this.listaAnimadosEliminados = new LinkedList<PersonajeAnimado>();
		this.listaAnimadosAgregados = new LinkedList<PersonajeAnimado>();
		                
		for (int fila = 0; fila < FILAS; fila++) {
			for (int columna = 0; columna < COLUMNAS; columna++) {
				this.tablero[fila][columna] = new Casillero();
			}
		}
	}
	
	public static Juego getInstance() {
		if (juego == null) {
			juego = new Juego();
		}
		return juego;
		
	}
	
	public void comenzarJuego() {
		int turno = 0;
		while (!nivel.isFin() && turno < 100) {
			System.out.println("Turno numero " + turno);
			ejecutarTurno();
			turno++;
		}
		
	}

	
	public void ejecutarTurno() {
		actualizarListaAnimados();
		for (PersonajeAnimado personaje : listaAnimados) {
			if (!(listaAnimadosEliminados.contains(personaje))){
				personaje.ejecutarTurno();
			}
		}
	}
	
	
	private void actualizarListaAnimados() {
		for (PersonajeAnimado personaje : this.listaAnimadosEliminados) {
			this.listaAnimados.remove(personaje);
		}
		for (PersonajeAnimado personaje : this.listaAnimadosAgregados) {
			this.listaAnimados.add(personaje);
		}
		this.listaAnimadosEliminados.clear();
		this.listaAnimadosAgregados.clear();
	}
	
	/**
	 * Método para asignar un personaje en una posición del tablero. 
	 * @param personaje
	 */
	public void setPersonaje(Personaje personaje) {
		
		
		//System.out.println("Agregando personaje: " + personaje + " en posicion " + personaje.getPosicion());
		// agregar el personaje al casillero correspondiente
		
		int fila = personaje.getPosicion().getFila();
		int columna = personaje.getPosicion().getColumna();
		
		Personaje personajeAnterior = this.tablero[fila][columna].getPersonaje();
		if (personajeAnterior != null) {
			
		}
		tablero[fila][columna].setPersonaje(personaje);
		if ((personajeAnterior != null) && (personajeAnterior instanceof PersonajeAnimado)) {
			listaAnimadosEliminados.add((PersonajeAnimado) personajeAnterior);
		}
		if (personaje instanceof PersonajeAnimado) {
			listaAnimadosAgregados.add((PersonajeAnimado) personaje);
		}

		//System.out.println(casilleros[personaje.getPosicion().getFila()][personaje.getPosicion().getColumna()].getPersonaje());
		
	}
	
	public Personaje getPersonaje(Posicion posicion){
		return tablero[posicion.getFila()][ posicion.getColumna()].getPersonaje();	
	}

	public Personaje getPersonaje(int fila, int columna){
		return tablero[fila][columna].getPersonaje();	
	}


	
	public void setNivel(Nivel nivel) {
		this.nivel = nivel;
	}
	public Nivel getNivel() {
		return this.nivel;
	}
	
	public void sumarDiamante() {
		
	}
	
	public boolean cargarNievel(int numeroNivel) {
		
		BDLevelReader levelReader = new BDLevelReader();
		try {
			int nivelesDisponibles = levelReader.readLevels("levels.xml");
		
			if ((numeroNivel > nivelesDisponibles) || (numeroNivel < 0)) {
				System.out.println("Nivel no disponible. Hay " + nivelesDisponibles + " niveles disponibles.");
				return false;
			} else {
				
				levelReader.setCurrentLevel(numeroNivel);
				//levelReader.imprimirMapa();
				Nivel nivel = new Nivel();
				nivel.setDiamantesNecesarios(levelReader.getDiamondsNeeded());
				cargarTablero(levelReader);
				nivel.setDisposicionInicial(tablero);
				this.setNivel(nivel);
				return true;
			}

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	
	private void cargarTablero(BDLevelReader levelReader) {
		for (int fila = 0; fila < levelReader.getHEIGHT(); fila++) {
			for (int col = 0; col < levelReader.getWIDTH(); col++) {
				Posicion posicionAuxiliar = new Posicion(0, 0);
				posicionAuxiliar.setFila(fila);
				posicionAuxiliar.setColumna(col);
				switch (levelReader.getTile(col, fila)) {
				case EMPTY:
					new LugarVacio(posicionAuxiliar);
					break;
				case DIRT:
					new Basura(posicionAuxiliar);
					break;
				case TITANIUM:
					new MuroTitanio(posicionAuxiliar);
					break;
				case WALL:
					new Muro(posicionAuxiliar);
					break;
				case ROCK:
					new Roca(posicionAuxiliar);
					break;
				case FALLINGROCK:
					new Roca(posicionAuxiliar);
					break;
				case DIAMOND:
					new Diamante(posicionAuxiliar);
					break;
				case FALLINGDIAMOND:
					new Diamante(posicionAuxiliar);
					break;
				case AMOEBA:
					new Ameba(posicionAuxiliar);
					break;
				case FIREFLY:
					new Luciernaga(posicionAuxiliar);
					break;
				case BUTTERFLY:
					new Mariposa(posicionAuxiliar);
					break;
				case EXIT:
					new Salida(posicionAuxiliar);
					break;
				case PLAYER:
					Rockford.getInstance(posicionAuxiliar);
					break;						
				}
			}				
		}
		
	}
	
	
}
