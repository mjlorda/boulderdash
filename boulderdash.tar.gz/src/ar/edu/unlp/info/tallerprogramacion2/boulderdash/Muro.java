/**
 * 
 */
package ar.edu.unlp.info.tallerprogramacion2.boulderdash;

/**
 * @author mario
 *
 */
public class Muro extends Personaje {
	
	public Muro(Posicion posicion) {
		super(posicion);
		
	}
}
