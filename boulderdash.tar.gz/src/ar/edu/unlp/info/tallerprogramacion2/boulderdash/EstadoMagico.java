/**
 * 
 */
package ar.edu.unlp.info.tallerprogramacion2.boulderdash;

/**
 * @author mario
 *
 */
public enum EstadoMagico {
	MAGICO,
	NORMAL
}
