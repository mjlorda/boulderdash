/**
 * 
 */
package ar.edu.unlp.info.tallerprogramacion2.boulderdash;

/**
 * @author mario
 *
 */
public class Salida extends Personaje {
	
	public Salida(Posicion posicion) {
		super(posicion);
		
	}
}
