/**
 * 
 */
package ar.edu.unlp.info.tallerprogramacion2.boulderdash;

/**
 * @author mario
 *
 */
public class Diamante extends PersonajeEstacionario{	
	
	public Diamante(Posicion posicion) {
		super(posicion);
		
	}
	
}
