/**
 * 
 */
package ar.edu.unlp.info.tallerprogramacion2.boulderdash;

/**
 * @author mario
 *
 */
public class MuroTitanio extends Muro {
	
	public MuroTitanio(Posicion posicion) {
		super(posicion);
		
	}
	
	
}
