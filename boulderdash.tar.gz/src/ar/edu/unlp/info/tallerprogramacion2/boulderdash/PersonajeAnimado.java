/**
 * 
 */
package ar.edu.unlp.info.tallerprogramacion2.boulderdash;

/**
 * @author mario
 *
 */
public interface PersonajeAnimado {
	public void ejecutarTurno();
}
