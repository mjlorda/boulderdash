package ar.edu.unlp.info.tallerprogramacion2.boulderdash;

public abstract class Personaje {
	
	private Posicion posicion;
	private Juego juego;

	public Juego getJuego() {
		return Juego.getInstance();
	}

	public Personaje(Posicion posicion) {
		this.posicion = posicion;
		this.juego = Juego.getInstance();
		this.juego.setPersonaje(this);
	}

	public Personaje(int fila, int columna) {
		this.posicion = new Posicion(fila, columna);
		this.juego = Juego.getInstance();
		this.juego.setPersonaje(this);
	}
	
	public Posicion getPosicion() {
		return posicion;
	}

	public void setPosicion(Posicion posicion) {
		mensaje(this + " se movio a la posicion " + posicion);
		Posicion posicionAnterior = this.posicion;
		this.posicion = posicion;
		this.juego.setPersonaje(new LugarVacio(posicionAnterior));
		this.juego.setPersonaje(this);
	}
	
	public void setPosicion(int fila, int columna) {
		Posicion nueva = new Posicion(fila, columna);
		mensaje(this + " se movio a la posicion " + posicion);
		Posicion posicionAnterior = this.posicion;
		this.posicion = nueva;
		this.juego.setPersonaje(new LugarVacio(posicionAnterior));
		this.juego.setPersonaje(this);
	}
	
	
	public void explotar() {
		mensaje(this + " explotó");
		int filaActual = getPosicion().getFila();
		int columnaActual = getPosicion().getColumna();
		Personaje personajeAdyacente;
		
		for (int y = filaActual - 1; y <= filaActual + 1; y++) {
			for (int x = columnaActual - 1; x <= columnaActual + 1; x++) {
				personajeAdyacente = this.juego.getPersonaje(y, x);
				/*Cualquier personaje que no sea Rockford lo transformo en LugarVacio
				 * para que no provoque explosión en cadena
				 */
				if (!(personajeAdyacente instanceof Rockford)) {
					this.juego.setPersonaje(new LugarVacio(y, x));
				}
				this.juego.getPersonaje(y, x).explotar();
			}
		}
	}

	
	public String toString() {
		return getClass().getSimpleName() + " en " + this.getPosicion();
	}
		
	public void mensaje(String mensaje) {
		System.out.println(mensaje);
	}
	
	@Override
	public boolean equals(Object o) {
		if (!(o == null)) {
			if (o.getClass() == this.getClass()) {
				
				if (((Personaje) o).getPosicion().equals(this.posicion)) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
	
}
