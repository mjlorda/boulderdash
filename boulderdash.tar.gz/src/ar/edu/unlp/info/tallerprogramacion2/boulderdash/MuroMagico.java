/**
 * 
 */
package ar.edu.unlp.info.tallerprogramacion2.boulderdash;

/**
 * @author mario
 *
 */
public class MuroMagico extends Muro {
	public MuroMagico(Posicion posicion) {
		super(posicion);
	}

}
