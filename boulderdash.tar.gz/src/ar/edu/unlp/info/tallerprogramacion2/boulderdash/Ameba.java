package ar.edu.unlp.info.tallerprogramacion2.boulderdash;

import java.util.Random;

public class Ameba extends PersonajeOrientable {
	private Random random;
	
	private Random getRandom() {
		return random;
	}


	private void setRandom(Random random) {
		this.random = random;
	}


	public Ameba(int fila, int columna) {
		super(fila, columna);
		// TODO Auto-generated constructor stub
	}


	public Ameba(Posicion posicion) {
		super(posicion);
		random  = new Random();
	}
	
	
	//public void explotarMariposa(Mariposa) {
	public void crecer() {
		//ToDo: comportamiento para que crezca en forma aleatoria
		
		//System.out.println("La ameba se expandió a la posicion " + posiciones[posiciones.length].toString());
	}

	@Override
	public void ejecutarTurno() {
		getRandom().setSeed(System.currentTimeMillis());
		int intAleatorio = getRandom().nextInt(10);
		int fila = getPosicion().getFila();
		int columna = getPosicion().getColumna();
		
		
		switch (intAleatorio){
		case 1:
			columna++;
			//setOrientacion(Orientacion.DERECHA);
			break;
		case 2:
			fila++;
			//setOrientacion(Orientacion.ABAJO);
			break;
		case 3:
			columna--;
			//setOrientacion(Orientacion.IZQUIERDA);
			break;
		case 4:
			fila--;
			//setOrientacion(Orientacion.ARRIBA);
			break;
		default:
			/* si el numero aleatorio no esta entre 1 y 4 salir sin intentar moverse */
			return;
		}

		Posicion posicionDestino = new Posicion(fila, columna);
		Personaje personajeDestino = Juego.getInstance().getPersonaje(posicionDestino);
		
		if ((personajeDestino instanceof LugarVacio) || (personajeDestino instanceof Basura)) {
			Juego.getInstance().setPersonaje(new Ameba(posicionDestino));
		}
	}
	
}


