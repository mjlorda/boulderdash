/**
 * 
 */
package ar.edu.unlp.info.tallerprogramacion2.boulderdash;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * @author mario
 *
 */
public class Tablero {
	public final int FILAS = 22;
	public final int COLUMNAS = 40;
	
	private Casillero[][] casilleros;
	private static Tablero tablero;
	
	/**
	 * Lista de personajes animados, la cual es recorrida en cada turno para que cada personaje
	 * realice las acciones que le corresponden
	 */
	private List<PersonajeAnimado> listaAnimados;
	/**
	 * Lista donde se cargan los personajes que se van eliminando durante un turno, que seran removidos 
	 * de la listaAnimados al finalizar el turno.
	 */
	private List<PersonajeAnimado> listaAnimadosEliminados;
	
	
	
	private Tablero() {
		casilleros = new Casillero[FILAS][COLUMNAS];
		listaAnimados = new LinkedList<PersonajeAnimado>();
		listaAnimadosEliminados = new LinkedList<PersonajeAnimado>();
		
		for (int n = 0; n < FILAS; n++) {
			for (int m = 0; m < COLUMNAS; m++) {
				casilleros[n][m] = new Casillero();
			}
		}
	}
	
	public static Tablero getInstance() {
		if (tablero == null) {
			tablero = new Tablero();
		}
		return tablero;
	}

	
	
}
